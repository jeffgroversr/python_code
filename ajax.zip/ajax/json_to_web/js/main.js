var pageCounter = 1;
var animalContainer = document.getElementById("animal-info");
var btn = document.getElementById("btn");

btn.addEventListener("click", function() {
  var ourRequest = new XMLHttpRequest();
  ourRequest.open('GET', 'http://bayesniffer.com/json_to_web/json/HCAHPS.json');
  ourRequest.onload = function() {
    if (ourRequest.status >= 200 && ourRequest.status < 400) {
      var ourData = JSON.parse(ourRequest.responseText);
      renderHTML(ourData);
    } else {
      console.log("We connected to the server, but it returned an error.");
    }
    
  };

  ourRequest.onerror = function() {
    console.log("Connection error");
  };

  ourRequest.send();

  if (pageCounter = 1) {
    btn.classList.add("hide-me");
  }
});

function renderHTML(data) {
  var htmlString = "";

  for (i = 0; i < data.length; i++) {htmlString += "<p>" + data[i].Hospital_Name + ": "+"Star 1 = " + data[i].Star_1 + " | "  + "Star 2 = " + data[i].Star_2 + " | "  + "Star 3 = " + data[i].Star_3 + " | "  + "Star 4 = " + data[i].Star_4 + " | "  + "Star 5 = " + data[i].Star_5 + " | "  + "Star ALL = " + data[i].Star_All;
    htmlString += '.</p>';}


  animalContainer.insertAdjacentHTML('beforeend', htmlString);
}

