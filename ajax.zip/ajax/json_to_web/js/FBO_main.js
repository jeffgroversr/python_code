var pageCounter = 1;
var animalContainer = document.getElementById("animal-info");
var btn = document.getElementById("btn");

btn.addEventListener("click", function() {
  var ourRequest = new XMLHttpRequest();
  ourRequest.open('GET', 'http://bayesniffer.com/json_to_web/json/FBO.json');
  ourRequest.onload = function() {
    if (ourRequest.status >= 200 && ourRequest.status < 400) {
      var ourData = JSON.parse(ourRequest.responseText);
      renderHTML(ourData);
    } else {
      console.log("We connected to the server, but it returned an error.");
    }
    
  };

  ourRequest.onerror = function() {
    console.log("Connection error");
  };

  ourRequest.send();

  if (pageCounter = 1) {
    btn.classList.add("hide-me");
  }
});

function renderHTML(data) {
  var htmlString = "";

  for (i = 0; i < data.length; i++){htmlString +=  "<p>"  +  "Solicitation No: " + data[i].solicitationNumber +":  " + "Type = " + data[i].baseType + "Link"+  " | " + "department = " + data[i].department +  " | " + "NAICS = " + data[i].naicsCode +  " | " + "Office = " + data[i].office +  " | " + "Date = " + data[i].postedDate +  " | " + "Response Deadline = " + data[i].responseDeadLine +  " | " + "Subtier = " + data[i].subTier + " | " +  "Title = " + data[i].title + " | " +  "Type = " + data[i].type + " | " +  "Type of Set Aside = " + data[i].typeOfSetAside + " | " +  "<a href="+data[i].uiLink+">beta.sam.gov link</a>";
    htmlString += '.</p>';}


  animalContainer.insertAdjacentHTML('beforeend', htmlString);
}

