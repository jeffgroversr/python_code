var pageCounter = 1;
var animalContainer = document.getElementById("animal-info");
var btn = document.getElementById("btn");

btn.addEventListener("click", function() {
  var ourRequest = new XMLHttpRequest();
  ourRequest.open('GET', 'http://bayesniffer.com/json_to_web/json/CD.json');
  ourRequest.onload = function() {
    if (ourRequest.status >= 200 && ourRequest.status < 400) {
      var ourData = JSON.parse(ourRequest.responseText);
      renderHTML(ourData);
    } else {
      console.log("We connected to the server, but it returned an error.");
    }
    
  };

  ourRequest.onerror = function() {
    console.log("Connection error");
  };

  ourRequest.send();

  if (pageCounter = 1) {
    btn.classList.add("hide-me");
  }
});

function renderHTML(data) {
  var htmlString = "";

  for (i = 0; i < data.length; i++) {htmlString += "<p>" + data[i].Hospital_Name +":  " + "Better than the National Rate = " + data[i].Better_Than_the_National_Rate + " | " + "Better than the National Value = " + data[i].Better_Than_the_National_Value +  " | " + "No Different than_the National Rate = " + data[i].No_Different_Than_the_National_Rate +  " | " + "No_Different than the National Value = " + data[i].No_Different_Than_the_National_Value +  " | " + "Number of Cases too Small = " + data[i].Number_of_Cases_Too_Small +  " | " + "Worse than the National Rate = " + data[i].Worse_Than_the_National_Rate  +  " | " + "Worse than the National Value = " + data[i].Worse_Than_the_National_Value + " | " +  "ALL = " + data[i].All;
    htmlString += '.</p>';}
  animalContainer.insertAdjacentHTML('beforeend', htmlString);
}

